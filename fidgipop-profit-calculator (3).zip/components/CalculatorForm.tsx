
import React from 'react';
import { CalculatorInputs, ProductUnit } from '../types';
import InputSlider from './InputSlider';

interface CalculatorFormProps {
  inputs: CalculatorInputs;
  onUnitChange: (index: number, field: keyof Omit<ProductUnit, 'id'>, value: string | number) => void;
  onAddUnit: () => void;
  onRemoveUnit: (index: number) => void;
  onGlobalInputChange: (field: 'shippingCosts' | 'taxRate', value: number) => void;
}

const CalculatorForm: React.FC<CalculatorFormProps> = ({ inputs, onUnitChange, onAddUnit, onRemoveUnit, onGlobalInputChange }) => {
  return (
    <div className="bg-slate-800/50 backdrop-blur-sm p-6 rounded-2xl border border-slate-700/50 shadow-2xl shadow-purple-500/10">
      <h2 className="text-2xl font-bold mb-6 text-slate-100">Your Business Metrics</h2>
      
      <div className="space-y-6">
        {inputs.productUnits.map((unit, index) => (
          <div key={unit.id} className="bg-slate-900/40 p-4 rounded-lg border border-slate-700 relative transition-all">
            {inputs.productUnits.length > 1 && (
              <button 
                onClick={() => onRemoveUnit(index)}
                className="absolute top-3 right-3 text-slate-400 hover:text-red-400 transition-colors z-10"
                aria-label="Remove Product"
              >
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                  <path fillRule="evenodd" d="M9 2a1 1 0 00-.894.553L7.382 4H4a1 1 0 000 2v10a2 2 0 002 2h8a2 2 0 002-2V6a1 1 0 100-2h-3.382l-.724-1.447A1 1 0 0011 2H9zM7 8a1 1 0 012 0v6a1 1 0 11-2 0V8zm4 0a1 1 0 012 0v6a1 1 0 11-2 0V8z" clipRule="evenodd" />
                </svg>
              </button>
            )}

            <div className="space-y-4">
              <div>
                <label htmlFor={`productName-${unit.id}`} className="block text-sm font-medium text-slate-300 mb-1">
                  Product Name
                </label>
                <input
                  type="text"
                  id={`productName-${unit.id}`}
                  value={unit.name}
                  onChange={(e) => onUnitChange(index, 'name', e.target.value)}
                  className="w-full bg-slate-900/50 border border-slate-700 rounded-md py-2 px-3 text-white focus:ring-2 focus:ring-purple-500 focus:border-purple-500 transition"
                />
              </div>

              <InputSlider
                label="Selling Price per Unit"
                id={`sellingPrice-${unit.id}`}
                value={unit.sellingPrice}
                onChange={(val) => onUnitChange(index, 'sellingPrice', val)}
                min={1}
                max={100}
                step={0.5}
                unit="$"
              />
              <InputSlider
                label="Units Sold"
                id={`unitsSold-${unit.id}`}
                value={unit.unitsSold}
                onChange={(val) => onUnitChange(index, 'unitsSold', val)}
                min={1}
                max={1000}
                step={1}
              />
              <InputSlider
                label="Cost per Unit (Supplier)"
                id={`costPerUnit-${unit.id}`}
                value={unit.costPerUnit}
                onChange={(val) => onUnitChange(index, 'costPerUnit', val)}
                min={0.5}
                max={50}
                step={0.25}
                unit="$"
              />
            </div>
          </div>
        ))}

        <button 
          onClick={onAddUnit}
          className="w-full flex items-center justify-center gap-2 bg-purple-600 hover:bg-purple-700 text-white font-semibold py-2 px-4 rounded-md transition-colors"
        >
          <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
            <path fillRule="evenodd" d="M10 3a1 1 0 011 1v5h5a1 1 0 110 2h-5v5a1 1 0 11-2 0v-5H4a1 1 0 110-2h5V4a1 1 0 011-1z" clipRule="evenodd" />
          </svg>
          Add Another Product
        </button>

        <hr className="border-slate-700" />
        
        <div className="space-y-6">
          <InputSlider
            label="Shipping & Other Costs"
            id="shippingCosts"
            value={inputs.shippingCosts}
            onChange={(val) => onGlobalInputChange('shippingCosts', val)}
            min={0}
            max={500}
            step={1}
            unit="$"
          />
          <InputSlider
            label="Income Tax Rate"
            id="taxRate"
            value={inputs.taxRate}
            onChange={(val) => onGlobalInputChange('taxRate', val)}
            min={0}
            max={50}
            step={1}
            unit="%"
          />
        </div>
      </div>
    </div>
  );
};

export default CalculatorForm;
