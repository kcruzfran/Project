
import React from 'react';
import { CalculationResults } from '../types';
import ResultCard from './ResultCard';

interface ResultsDisplayProps {
  results: CalculationResults;
}

const ResultsDisplay: React.FC<ResultsDisplayProps> = ({ results }) => {
  return (
    <div className="bg-slate-800/30 backdrop-blur-sm p-6 rounded-2xl border border-slate-700/50 shadow-2xl shadow-pink-500/10 h-full">
      <h2 className="text-2xl font-bold mb-6 text-slate-100">Financial Breakdown</h2>
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <ResultCard
          label="Total Revenue"
          value={results.revenue}
          description="From all products sold"
        />
        <ResultCard
          label="Cost of Goods Sold (COGS)"
          value={-results.cogs}
          description="Cost of all products from supplier"
          isNegative
        />
        <ResultCard
          label="Gross Profit"
          value={results.grossProfit}
          description="Revenue - COGS"
        />
        <ResultCard
          label="Net Profit (Before Tax)"
          value={results.netProfitBeforeTax}
          description="Gross Profit - Other Costs"
        />
        <ResultCard
          label="Income Tax"
          value={-results.incomeTax}
          description="Based on Net Profit"
          isNegative
        />
        <div className="sm:col-span-2">
          <ResultCard
            label="Your Take-Home Profit"
            value={results.netProfitAfterTax}
            description="The final amount you keep!"
            isHighlighted
          />
        </div>
      </div>
    </div>
  );
};

export default ResultsDisplay;
