
import React from 'react';

const Header: React.FC = () => {
  return (
    <header className="text-center">
      <h1 className="text-4xl sm:text-5xl md:text-6xl font-black text-transparent bg-clip-text bg-gradient-to-r from-purple-400 via-pink-500 to-red-500">
        FidgiPop
      </h1>
      <p className="mt-2 text-lg text-slate-300">Profit Calculator</p>
    </header>
  );
};

export default Header;
