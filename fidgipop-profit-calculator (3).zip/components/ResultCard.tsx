
import React from 'react';

interface ResultCardProps {
  label: string;
  value: number;
  description: string;
  isNegative?: boolean;
  isHighlighted?: boolean;
}

const formatCurrency = (amount: number) => {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }).format(amount);
};

const ResultCard: React.FC<ResultCardProps> = ({ label, value, description, isNegative = false, isHighlighted = false }) => {
  const valueColor = isNegative ? 'text-red-400' : 'text-green-400';
  const highlightedClasses = isHighlighted 
    ? 'bg-gradient-to-br from-purple-600 via-pink-600 to-red-600' 
    : 'bg-slate-700/50';
  const highlightedTextColor = isHighlighted ? 'text-white' : 'text-slate-300';
  const highlightedValueColor = isHighlighted ? 'text-white' : valueColor;

  return (
    <div className={`p-4 rounded-lg flex flex-col justify-between h-full ${highlightedClasses}`}>
      <div>
        <p className={`text-sm font-medium ${highlightedTextColor}`}>{label}</p>
        <p className={`text-3xl font-bold mt-1 ${highlightedValueColor}`}>
          {formatCurrency(value)}
        </p>
      </div>
      <p className={`text-xs mt-2 ${isHighlighted ? 'text-purple-200' : 'text-slate-400'}`}>
        {description}
      </p>
    </div>
  );
};

export default ResultCard;
