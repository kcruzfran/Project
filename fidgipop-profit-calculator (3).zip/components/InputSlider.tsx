
import React from 'react';

interface InputSliderProps {
  label: string;
  id: string;
  value: number;
  onChange: (value: number) => void;
  min: number;
  max: number;
  step: number;
  unit?: string;
}

const InputSlider: React.FC<InputSliderProps> = ({ label, id, value, onChange, min, max, step, unit }) => {
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const numValue = e.target.value === '' ? 0 : parseFloat(e.target.value);
    if (!isNaN(numValue)) {
      onChange(numValue);
    }
  };

  return (
    <div>
      <label htmlFor={id} className="block text-sm font-medium text-slate-300 mb-1">
        {label}
      </label>
      <div className="flex items-center space-x-4">
        <input
          type="range"
          id={`${id}-range`}
          min={min}
          max={max}
          step={step}
          value={value}
          onChange={handleInputChange}
          className="w-full h-2 bg-slate-700 rounded-lg appearance-none cursor-pointer [&::-webkit-slider-thumb]:appearance-none [&::-webkit-slider-thumb]:h-4 [&::-webkit-slider-thumb]:w-4 [&::-webkit-slider-thumb]:rounded-full [&::-webkit-slider-thumb]:bg-pink-500"
        />
        <div className="relative">
          {unit === '$' && <span className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400">$</span>}
          <input
            type="number"
            id={id}
            value={value}
            onChange={handleInputChange}
            min={min}
            max={max}
            step={step}
            className={`w-28 bg-slate-900/50 border border-slate-700 rounded-md py-2 text-center text-white focus:ring-2 focus:ring-purple-500 focus:border-purple-500 transition ${unit === '$' ? 'pl-7' : ''} ${unit === '%' ? 'pr-7' : ''}`}
          />
          {unit === '%' && <span className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400">%</span>}
        </div>
      </div>
    </div>
  );
};

export default InputSlider;
